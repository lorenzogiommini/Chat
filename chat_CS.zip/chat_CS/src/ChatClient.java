import javax.swing.*;
import java.awt.*;

/**
 * interfaccia grafica client
 */

public class ChatClient extends JFrame {

    public ChatClient() {
        super("Chat Client");
        this.setSize(new Dimension(500, 300)); //setto la grandezza della finestra
        this.setLocationRelativeTo(null);                  //la metto al centro dello schermo
        this.setEnabled(true);                             //setto la proprietà enable
        this.setBackground(Color.red);                     //setto il colore di sfondo
        //creo il panello per l'inserimento e la visualizzazione dei messaggi
        PannelloChatClient pan = new PannelloChatClient();
        this.getContentPane().add(pan);
        this.setVisible(true);
    }

    public static void main(String[] args) {
       new ChatClient();
    }
}
