import java.awt.*;
import java.net.*;
import java.io.*;
import javax.swing.*;

/**
 * Thread che si occupa di ricevere le connessioni dei client
 */
public class ThreadGestioneServizioChat implements Runnable{
    private int maxConnessioni; //numero massimo di connessioni
    private List lista_messaggi; //lista dei messaggi dei client
    private ThreadChatConnesioni[] listaconnessioni;
    Thread me;
    private ServerSocket serverChat; //creazione di un socket per accettare le connesioni

    public ThreadGestioneServizioChat(int maxConnessioni, List lista_messaggi) {
        this.maxConnessioni = maxConnessioni-1;
        this.lista_messaggi = lista_messaggi;
        this.listaconnessioni = new ThreadChatConnesioni[this.maxConnessioni]; //si crea la lista di connesioni
        me = new Thread(this);
        me.start();
    }
    @Override
    public void run() {
        boolean continua = true;
        //istanzio la connesione del server per la chat
        try {
            serverChat = new ServerSocket(6789);  //creazione connection socket
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Impossibile istanziare il server: " + e.getMessage());
            continua = false;
        }


        //se l'operazione va a buon fine si procede con la creazione di un thread per ogni connesione
        if(continua) {
            //accetto le connesioni chat
            try {
                for(int xx=0; xx<maxConnessioni; xx++) {
                    Socket tempo = null;  //creo il data socket
                    tempo = serverChat.accept();
                    listaconnessioni[xx] = new ThreadChatConnesioni(this, tempo);
                }
                serverChat.close(); //termina l'uso del socket
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null,"Impossibile istanziare il server chat");
            }
        }
    }

    //metodo che invia un messaggio ai client
    public void spedisciMessaggio(String mex) {
        //si inserisce il messaggio nella lista
        lista_messaggi.add(mex);
        lista_messaggi.select(lista_messaggi.getItemCount()-1);
        //mando il messaggio
        for(int xx = 0; xx < this.maxConnessioni; xx++) {
            if(listaconnessioni[xx] != null) { //se ci sono connessioni
                listaconnessioni[xx].spedisciMessaggioChat(mex);

            }
        }
    }
}
