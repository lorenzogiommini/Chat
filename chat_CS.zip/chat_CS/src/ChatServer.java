import javax.swing.*;
import java.awt.*;

/**
 * interfaccia grafica del server
 */
public class ChatServer extends JFrame {

    public static void main(String[] args) {
            new ChatServer();
    }

    public ChatServer() {
        super("Chat Server");
        this.setSize(new Dimension(500, 300));
        this.setLocationRelativeTo(null);
        this.setEnabled(true);
        this.setBackground(Color.blue);

        PannelloChatServer pan = new PannelloChatServer();
        this.setContentPane(pan);  // Imposta il pannello come contenuto del JFrame

        this.setVisible(true);
    }
}
