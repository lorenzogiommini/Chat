import java.net.*;
import java.io.*;

/**
 * classe associata ad ogni client connesso al server
 */
public class ThreadChatConnesioni implements Runnable{

    private ThreadGestioneServizioChat gestoreChat;
    private Socket client;  //socket client
    private BufferedReader input = null;  //steram di input
    private PrintWriter output = null;   //stream di output
    Thread me;

    public ThreadChatConnesioni(ThreadGestioneServizioChat gestoreChat, Socket client) {
        this.gestoreChat = gestoreChat;
        this.client = client;

        try {
            this.input = new BufferedReader(new InputStreamReader(client.getInputStream()));
            this.output = new PrintWriter(this.client.getOutputStream(), true);
        }catch (Exception e){
            output.println("Errore nella lettura.");
        }
        me = new Thread(this);
        me.start();
    }
    @Override
    public void run() {
        while(true) {
            try {
                String mex = null;
                //rimango in attesa dei messaggi mandati dal client
                while((mex = input.readLine()) == null) {}
                //invoco il metodo del gestoreChat per ripertere a tutti il messaggio ricevuto
                gestoreChat.spedisciMessaggio(mex);
            } catch(Exception e) {
                output.println("Errore nell'invio del messaggio a tutti");
            }
        }
    }

    //metodo che invia un messaggio a un singolo client
    public void spedisciMessaggioChat(String messaggio) {
        try {
            output.println("Server: " + messaggio);
        }catch(Exception e) {
            output.println("Errore nella spedizione del singolo messaggio");
        }
    }
}
