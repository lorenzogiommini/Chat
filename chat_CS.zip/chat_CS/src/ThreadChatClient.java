import java.net.*;
import java.io.*;
import java.awt.*;

/**
 * servizio client sulla chat
 *
 */
public class ThreadChatClient implements Runnable {

    private List lista;
    private Socket socket;
    private PrintWriter output;
    private BufferedReader input;

    public ThreadChatClient(List lista, String serverIP, int serverPort) {
        this.lista = lista;
        try {
            socket = new Socket(serverIP, serverPort);
            output = new PrintWriter(socket.getOutputStream(), true);
            input = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            Thread thread = new Thread(this);
            thread.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        try {
            while (true) {
                String messaggio = input.readLine();
                lista.add(messaggio);
                lista.select(lista.getItemCount() - 1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void spedisciMessaggioChat(String messaggio) {
        output.println("Client:" + messaggio);
    }
}
